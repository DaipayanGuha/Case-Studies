package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionDAO{

	@Override
	public Transaction save(long accountNo, Transaction transaction) {
		transaction.setTransactionId(BankingDBUtil.generateTRANSACTION_ID());
		BankingDBUtil.customerDetails.get(accountNo).getTransactions().put(transaction.getTransactionId(),transaction);
		return transaction;
	}

	@Override
	public boolean update(long accountNo, Transaction transaction) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Transaction findOne(long accNo, int transactionId) {
		// TODO Auto-generated method stub
		return BankingDBUtil.customerDetails.get(accNo).getTransactions().get(transactionId);
	}

	@Override
	public List<Transaction> findAll(long accountNo) {
		// TODO Auto-generated method stub
		return new ArrayList<Transaction>(BankingDBUtil.customerDetails.get(accountNo).getTransactions().values());
	}
	
}
