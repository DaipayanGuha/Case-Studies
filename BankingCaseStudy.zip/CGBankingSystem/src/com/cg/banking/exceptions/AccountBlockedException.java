package com.cg.banking.exceptions;

public class AccountBlockedException extends RuntimeException{
	public AccountBlockedException() {
		super();
		System.out.println("Sorry; This account has been blocked!");
	}

	public AccountBlockedException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		System.out.println("Sorry; This account has been blocked!");
	}

	public AccountBlockedException(String message, Throwable cause) {
		super(message, cause);
		System.out.println("Sorry; This account has been blocked!");
	}

	public AccountBlockedException(String message) {
		super(message);
		System.out.println("Sorry; This account has been blocked!");
	}

	public AccountBlockedException(Throwable cause) {
		super(cause);
		System.out.println("Sorry; This account has been blocked!");
	}
	
}