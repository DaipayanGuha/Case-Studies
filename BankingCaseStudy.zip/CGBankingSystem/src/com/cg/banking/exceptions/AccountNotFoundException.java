package com.cg.banking.exceptions;

public class AccountNotFoundException extends RuntimeException{
	public AccountNotFoundException() {
		super();
		System.out.println("Account does not exist!");
	}

	public AccountNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		System.out.println("Account does not exist!");
	}

	public AccountNotFoundException(String message, Throwable cause) {
		super(message, cause);
		System.out.println("Account does not exist!");
	}

	public AccountNotFoundException(String message) {
		super(message);
		System.out.println("Account does not exist!");
	}

	public AccountNotFoundException(Throwable cause) {
		super(cause);
		System.out.println("Account does not exist!");
	}
	
}
