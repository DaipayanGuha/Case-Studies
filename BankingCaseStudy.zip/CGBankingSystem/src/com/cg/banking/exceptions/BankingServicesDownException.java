package com.cg.banking.exceptions;

public class BankingServicesDownException extends RuntimeException{
	BankingServicesDownException(){
		super();
		System.out.println("Sorry; The Bank servers are down!");
	}

	public BankingServicesDownException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		System.out.println("Sorry; The Bank servers are down!");
	}

	public BankingServicesDownException(String message, Throwable cause) {
		super(message, cause);
		System.out.println("Sorry; The Bank servers are down!");
	}

	public BankingServicesDownException(String message) {
		super(message);
		System.out.println("Sorry; The Bank servers are down!");
	}

	public BankingServicesDownException(Throwable cause) {
		super(cause);
		System.out.println("Sorry; The Bank servers are down!");
	}
	
}
