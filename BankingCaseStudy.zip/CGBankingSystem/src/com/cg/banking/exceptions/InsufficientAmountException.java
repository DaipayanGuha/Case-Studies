package com.cg.banking.exceptions;

public class InsufficientAmountException extends RuntimeException{

	public InsufficientAmountException() {
		super();
		System.out.println("Insufficient Amount in Account!");
	}

	public InsufficientAmountException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		System.out.println("Insufficient Amount in Account!");
	}

	public InsufficientAmountException(String message, Throwable cause) {
		super(message, cause);
		System.out.println("Insufficient Amount in Account!");
	}

	public InsufficientAmountException(String message) {
		super(message);
		System.out.println("Insufficient Amount in Account!");
	}

	public InsufficientAmountException(Throwable cause) {
		super(cause);
		System.out.println("Insufficient Amount in Account!");
	}
	
}
