package com.cg.banking.exceptions;

public class InvalidAmountException extends RuntimeException{
	public InvalidAmountException() {
		super();
		System.out.println("Invalid Amount!");
	}

	public InvalidAmountException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		System.out.println("Invalid Amount!");
	}

	public InvalidAmountException(String message, Throwable cause) {
		super(message, cause);
		System.out.println("Invalid Amount!");
	}

	public InvalidAmountException(String message) {
		super(message);
		System.out.println("Invalid Amount!");
	}

	public InvalidAmountException(Throwable cause) {
		super(cause);
		System.out.println("Invalid Amount!");
	}
	
}
