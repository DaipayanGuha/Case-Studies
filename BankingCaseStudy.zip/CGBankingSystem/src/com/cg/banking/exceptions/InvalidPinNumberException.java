package com.cg.banking.exceptions;

public class InvalidPinNumberException extends RuntimeException{
	
	public InvalidPinNumberException(){
		super();
		System.out.println("Invalid PIN Number!");
	}

	public InvalidPinNumberException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		System.out.println("Invalid PIN Number!");
	}

	public InvalidPinNumberException(String message, Throwable cause) {
		super(message, cause);
		System.out.println("Invalid PIN Number!");
	}

	public InvalidPinNumberException(String message) {
		super(message);
		System.out.println("Invalid PIN Number!");
	}

	public InvalidPinNumberException(Throwable cause) {
		super(cause);
		System.out.println("Invalid PIN Number!");
	}
}
