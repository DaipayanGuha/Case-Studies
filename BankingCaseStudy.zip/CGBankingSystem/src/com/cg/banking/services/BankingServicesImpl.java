package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
	
	AccountDAOImpl customerData = new AccountDAOImpl();
	Account customer = new Account();
	private TransactionDAOImpl transactions = new TransactionDAOImpl();
	
	private final static float minBalance = 1000;

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(initBalance<minBalance)
			throw new InvalidAccountTypeException();
		Account cust = customerData.save(new Account(accountType,initBalance));
		transactions.save(cust.getAccountNumber(), new Transaction(initBalance,"Deposit"));
		return cust;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customer = null;
		//customers = custData1.findOne(accountNo);
		customer = getAccountDetails(accountNo);
		if(customer.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else
			customer.setAccountBalance(customer.getAccountBalance()+amount);
		transactions.save(accountNo, new Transaction(amount, "Deposit"));
		return customer.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account customer = null;
		//customer = custData1.findOne(accountNo);
		customer = getAccountDetails(accountNo);
		if(customer.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		else if(customer.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException();
		else if(customer.getAccountBalance()-amount<=minBalance)
			throw new InsufficientAmountException();
		else
			customer.setAccountBalance(customer.getAccountBalance()-amount);
		transactions.save(accountNo, new Transaction(amount, "Withdraw"));
		return customer.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo = null;
		Account customerFrom = null;
		//customerTo = custData1.findOne(accountNoTo);
		//customerFrom = custData1.findOne(accountNoFrom);
		customerTo = getAccountDetails(accountNoTo);
		customerFrom = getAccountDetails(accountNoFrom);
		if(customerFrom.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException();
		else {
			customerFrom.setAccountBalance(withdrawAmount(customerFrom.getAccountNumber(), transferAmount, customerFrom.getPinNumber()));
			customerTo.setAccountBalance(depositAmount(customerTo.getAccountNumber(),transferAmount));
		}
		return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account customers = null;
		customers = customerData.findOne(accountNo);
		if(customers==null)
			throw new AccountNotFoundException();
		return customers;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		List<Account> customers = customerData.findAll();
		return customers;
		}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		return transactions.findAll(accountNo);
	}

	@Override
	public String accountStatus(long accountNo) throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException{
		Account customers = customerData.findOne(accountNo);
		if(customers==null)
			throw new AccountNotFoundException();
		else if(customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		return customers.getAccountStatus();
	}

}
