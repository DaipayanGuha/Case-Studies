package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDBUtil;

public class AccountDAOImpl implements AccountDAO{

	@Override
	public Account save(Account account) {
		account.setAccountNumber(BankingDBUtil.getACCOUNT_ID_COUNTER());
		//do
		//{
			account.setPinNumber((int)(Math.random()*1000));
		//}while(((account.getPinNumber())/1000)<1);
		BankingDBUtil.customerDetails.put(account.getAccountNumber(), account);
		return account;
	}

	@Override
	public boolean update(Account account) {
		if(BankingDBUtil.customerDetails.containsKey(account.getAccountNumber())) {
			BankingDBUtil.customerDetails.put(account.getAccountNumber(), account);
			return true;
		}
		return false;
	}

	@Override
	public Account findOne(long accountNo) {
		return BankingDBUtil.customerDetails.get(accountNo);
	}

	@Override
	public List<Account> findAll() {
		return new ArrayList<Account>(BankingDBUtil.customerDetails.values());
	}

}
