package com.cg.banking.main;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;;

public class MainClass {

	public static void main(String[] args) {
		
		long accountNumber;
		long accountNumberFrom, accountNumberTo;
		int pinNo;
		float amount;
		
		BankingServices bankingServices = new BankingServicesImpl();
		Account customer1 = null;
		Account customer2 = null;
		
		try {
			customer1 = bankingServices.openAccount("Savings", 2000);
			customer1.setAccountStatus("Active");
		}
		catch(InvalidAccountTypeException | InvalidAmountException | BankingServicesDownException e){
			e.printStackTrace();
		}
		
		try {
			customer2 = bankingServices.openAccount("Current", 3000);
			customer2.setAccountStatus("Active");
		}
		catch(InvalidAccountTypeException | InvalidAmountException | BankingServicesDownException e){
			e.printStackTrace();
		}
		
		System.out.println("Account Details :  " + customer1);
		System.out.println();
		System.out.println("Account Details :  " + customer2);
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("-------------Withdrawal-------------");
		System.out.println("Enter Account No. :");
		accountNumber = sc.nextLong();
		System.out.println("Enter PIN No. :");
		pinNo = sc.nextInt();
		System.out.println("Enter Withdraw Amount :");
		amount = sc.nextFloat();
		try {
			System.out.println(bankingServices.withdrawAmount(accountNumber, amount, pinNo));
			System.out.println("Account Details after Withdrawal : " +  bankingServices.getAccountDetails(accountNumber));
		}catch(InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException | BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}
		
		System.out.println("-------------Deposit-------------");
		System.out.println("Enter Account No. :");
		accountNumber = sc.nextLong();
		System.out.println("Enter Deposit Amount :");
		amount = sc.nextFloat();
		try {
			System.out.println(bankingServices.depositAmount(accountNumber, amount));
			System.out.println("Account Details after Withdrawal : " + bankingServices.getAccountDetails(accountNumber));
		}catch(AccountNotFoundException | BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}
		
		System.out.println("-------------Fund Transfer-------------");
		System.out.println("Enter account number of account from which to initiate tranfer :");
		accountNumberFrom = sc.nextLong();
		System.out.println("Enter PIN number :");
		pinNo = sc.nextInt();
		System.out.println("Enter account number of account where tranferred money will be deposited :");
		accountNumberTo = sc.nextLong();
		System.out.println("Enter transfer amount :");
		amount = sc.nextFloat();
		try{
			System.out.println("Fund Transfer Status : " + bankingServices.fundTransfer(accountNumberTo, accountNumberFrom, amount, pinNo));
			System.out.println("Account details after transfer :\n(from) :\n" + bankingServices.getAccountDetails(accountNumberFrom) + "\n(to) :\n" + bankingServices.getAccountDetails(accountNumberTo));
		}
		catch(InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException | BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}
		
	}

}
