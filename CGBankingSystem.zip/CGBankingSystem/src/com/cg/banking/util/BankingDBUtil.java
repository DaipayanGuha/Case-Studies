package com.cg.banking.util;

import java.util.HashMap;

import com.cg.banking.beans.Account;

public class BankingDBUtil {
	public static HashMap<Long, Account> customerDetails = new HashMap<>();
	
	private static int ACCOUNT_ID_COUNTER = 1000;
	private static int TRANSACTION_NUMBER = 100;

	public static int getACCOUNT_ID_COUNTER() {
		return ++ACCOUNT_ID_COUNTER;
	}
	
	public static int generateTRANSACTION_ID() {
		return ++TRANSACTION_NUMBER;
	}
	
}
