package com.cg.payroll.client;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String[] args) {

		PayrollServices services = new PayrollServicesImpl();

		int associateId1 = services.acceptAssociateDetails("Daipayan", "Guha", "dguha@gmail.com", "FullStackDev",
				"Intern", "321hg123", 9645325, 90000, 43243, 525, 86427531, "Citi", "CITI0552");
		System.out.println("Associate Id :- " + associateId1);
		int associateId2 = services.acceptAssociateDetails("Tirtharaj", "Sur", "tsur@gmail.com", "FullStackDev",
				"Intern", "321hg223", 9645326, 90500, 43241, 523, 86427532, "Citi", "CITI0551");
		System.out.println("Associate Id :- " + associateId2);

		Associate associate = null;

		try {
			associate = services.getAssociateDetails(associateId2);
			System.out.println("Associate ID1 details : " + associate);
			System.out.println("Annual Net Salary : " + services.calculateNetSalary(associate.getAssociateId()));

		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		try {
			associate = services.getAssociateDetails(associateId1);
			System.out.println("Associate ID1 details : " + associate);
			System.out.println("Annual Net Salary : " + services.calculateNetSalary(associate.getAssociateId()));
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}

		/*
		 * try { associate = services.getAssociateDetails(80);
		 * System.out.println("Associate ID1 details : " + 80);
		 * System.out.println("Annual Net Salary : " + services.calculateNetSalary(80));
		 * } catch(AssociateDetailsNotFoundException e) { e.printStackTrace(); }
		 * 
		 * List<Associate> a1 = services.getAllAssociateDetails(80); for(Associate
		 * associate2 : a1) { System.out.println(associate2); } }
		 */
	}

}
