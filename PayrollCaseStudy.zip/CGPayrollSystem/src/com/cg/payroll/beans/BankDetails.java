package com.cg.payroll.beans;

public class BankDetails {
	
	private int accountNumber;
	private String bankName,ifsccode;
	public BankDetails() {
		super();
	}
	
	public BankDetails(int accountNumber, String bankName, String ifsccode) {
		super();
		this.accountNumber = accountNumber;
		this.bankName = bankName;
		this.ifsccode = ifsccode;
	}

	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getIfsccode() {
		return ifsccode;
	}
	public void setIfsccode(String ifsccode) {
		this.ifsccode = ifsccode;
	}
	
	@Override
	public String toString() {
		return "BankDetails [accountNumber=" + accountNumber + ", bankName=" + bankName + ", ifsccode=" + ifsccode
				+ "]";
	}

}
