package com.cg.stuaddsystem.beans;

public class Department {
	
	private String deptName;
	private String deptCode;
	private String deptHod;
	private int durationYears;
	
	public Department() {}

	public Department(String deptName, String deptCode, String deptHod, int durationYears) {
		super();
		this.deptName = deptName;
		this.deptCode = deptCode;
		this.deptHod = deptHod;
		this.durationYears = durationYears;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getDeptHod() {
		return deptHod;
	}

	public void setDeptHod(String deptHod) {
		this.deptHod = deptHod;
	}

	public int getDurationYears() {
		return durationYears;
	}

	public void setDurationYears(int durationYears) {
		this.durationYears = durationYears;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((deptCode == null) ? 0 : deptCode.hashCode());
		result = prime * result + ((deptHod == null) ? 0 : deptHod.hashCode());
		result = prime * result + ((deptName == null) ? 0 : deptName.hashCode());
		result = prime * result + durationYears;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Department other = (Department) obj;
		if (deptCode == null) {
			if (other.deptCode != null)
				return false;
		} else if (!deptCode.equals(other.deptCode))
			return false;
		if (deptHod == null) {
			if (other.deptHod != null)
				return false;
		} else if (!deptHod.equals(other.deptHod))
			return false;
		if (deptName == null) {
			if (other.deptName != null)
				return false;
		} else if (!deptName.equals(other.deptName))
			return false;
		if (durationYears != other.durationYears)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Department [deptName=" + deptName + ", deptCode=" + deptCode + ", deptHod=" + deptHod
				+ ", durationYears=" + durationYears + "]";
	}
	
	
	
}
