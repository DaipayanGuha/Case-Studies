package com.cg.stuaddsystem.beans;

public class Student {
	
	private int studentId;
	private String studentName;
	private int studentAge;
	private String gender;
	private String studentEmailId;
	Department department;

	public Student() {}

	public Student(int studentId, String studentName, int studentAge, String gender, String studentEmailId,
			Department department) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentAge = studentAge;
		this.gender = gender;
		this.studentEmailId = studentEmailId;
		this.department = department;
	}
	

	public Student(String studentName, int studentAge, String gender, String studentEmailId, Department department) {
		super();
		this.studentName = studentName;
		this.studentAge = studentAge;
		this.gender = gender;
		this.studentEmailId = studentEmailId;
		this.department = department;
	}
	

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getStudentAge() {
		return studentAge;
	}

	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getStudentEmailId() {
		return studentEmailId;
	}

	public void setStudentEmailId(String studentEmailId) {
		this.studentEmailId = studentEmailId;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((department == null) ? 0 : department.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + studentAge;
		result = prime * result + ((studentEmailId == null) ? 0 : studentEmailId.hashCode());
		result = prime * result + studentId;
		result = prime * result + ((studentName == null) ? 0 : studentName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (department == null) {
			if (other.department != null)
				return false;
		} else if (!department.equals(other.department))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (studentAge != other.studentAge)
			return false;
		if (studentEmailId == null) {
			if (other.studentEmailId != null)
				return false;
		} else if (!studentEmailId.equals(other.studentEmailId))
			return false;
		if (studentId != other.studentId)
			return false;
		if (studentName == null) {
			if (other.studentName != null)
				return false;
		} else if (!studentName.equals(other.studentName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentAge=" + studentAge
				+ ", gender=" + gender + ", studentEmailId=" + studentEmailId + ", department=" + department + "]";
	}

	
	
	
}
