package com.cg.stuaddsystem.client;

import com.cg.stuaddsystem.beans.Student;
import com.cg.stuaddsystem.exceptions.StudentNotFound;
import com.cg.stuaddsystem.services.StuAddSystemServices;
import com.cg.stuaddsystem.services.StuAddSystemServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		
		StuAddSystemServices services = new StuAddSystemServicesImpl();
		
		int studentId1 = services.acceptStudentDetails(130, "Daipayan Guha", 22, "Male", "dguha@gmail.com", "CSE", "CS101", "S. Paul", 4);
		System.out.println("Associate Id :- " + studentId1);
		int studentId2 = services.acceptStudentDetails(130, "Tirtharaj Sur", 22, "Male", "tsur@gmail.com", "CSE", "CS101", "S. Paul", 4);
		System.out.println("Associate Id :- " + studentId2);

		Student student = null;
		
		try {
			student = services.getStudentDetails(studentId1);
			System.out.println("Student ID1 details : " + student);
		} catch (StudentNotFound e) {
			e.printStackTrace();
		}

		try {
			student = services.getStudentDetails(studentId2);
			System.out.println("Student ID1 details : " + student);
		} catch (StudentNotFound e) {
			e.printStackTrace();
		}
		

	}

}
