package com.cg.stuaddsystem.daoservices;

import java.util.List;

import com.cg.stuaddsystem.beans.Student;

public interface StudentDAO {
	
	Student save(Student student);
	boolean update(Student student );
	Student findOne(int studentId);
	List<Student> findAll();
}
