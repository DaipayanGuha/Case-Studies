package com.cg.stuaddsystem.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.stuaddsystem.beans.Student;
import com.cg.stuaddsystem.util.StudentDBUtil;

public class StudentDAOImpl implements StudentDAO{

	@Override
	public Student save(Student student) {
		student.setStudentId(StudentDBUtil.getSTUDENT_ID_COUNTER());
		StudentDBUtil.students.put(student.getStudentId(), student);
		return student;
	}

	@Override
	public boolean update(Student student) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Student findOne(int studentId) {
		return StudentDBUtil.students.get(studentId);
	}

	@Override
	public List<Student> findAll() {
		return new ArrayList<Student>(StudentDBUtil.students.values());
	}
	
	
}
