package com.cg.stuaddsystem.exceptions;

public class StudentNotFound extends Exception{

	public StudentNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentNotFound(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public StudentNotFound(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public StudentNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StudentNotFound(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
