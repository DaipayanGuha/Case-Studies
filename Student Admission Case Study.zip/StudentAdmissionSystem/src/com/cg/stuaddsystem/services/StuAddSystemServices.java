package com.cg.stuaddsystem.services;

import java.util.List;

import com.cg.stuaddsystem.beans.Student;
import com.cg.stuaddsystem.exceptions.StudentNotFound;


public interface StuAddSystemServices {
	
	int acceptStudentDetails(int studentId,String studentName,int studentAge, String gender,String studentEmailId,String deptName,String deptCode,String deptHod,int durationYears);
	
	Student getStudentDetails(int studentId)throws StudentNotFound;
	
	List<Student>getAllStudentDetails()throws StudentNotFound;
}
