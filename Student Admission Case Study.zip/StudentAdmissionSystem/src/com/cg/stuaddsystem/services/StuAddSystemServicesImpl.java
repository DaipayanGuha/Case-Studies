package com.cg.stuaddsystem.services;

import java.util.List;

import com.cg.stuaddsystem.beans.Department;
import com.cg.stuaddsystem.beans.Student;
import com.cg.stuaddsystem.daoservices.StudentDAO;
import com.cg.stuaddsystem.daoservices.StudentDAOImpl;
import com.cg.stuaddsystem.exceptions.StudentNotFound;

public class StuAddSystemServicesImpl implements StuAddSystemServices{
	
	private StudentDAO studentDao;
	
	public StuAddSystemServicesImpl() {
		studentDao = new StudentDAOImpl();
	}
	public StuAddSystemServicesImpl(StudentDAO studentDao) {
		super();
		this.studentDao = studentDao;
	}

	@Override
	public int acceptStudentDetails(int studentId,String studentName,int studentAge, String gender,String studentEmailId,String deptName,String deptCode,String deptHod, int durationYears) {
		Student student = new Student(studentName, studentAge, gender, studentEmailId, new Department(deptName, deptCode, deptHod, durationYears));		
		student = studentDao.save(student);
	return student.getStudentId();
	}

	@Override
	public Student getStudentDetails(int studentId) throws StudentNotFound {
		Student student = studentDao.findOne(studentId);
		if(student==null)
			throw new StudentNotFound("Student details not found for ID. : " + studentId);
		return student;
	}

	@Override
	public List<Student> getAllStudentDetails() throws StudentNotFound {
		List<Student> students = studentDao.findAll();
		if(students==null)
			throw new StudentNotFound("Student details  found for ID. : " + students);
		return students;
	}

}
